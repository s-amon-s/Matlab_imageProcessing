function Myautothre()
%% Read image
% store image in coin variale
    coin = (rgb2gray(imread('i4c_2015.jpg')));
%%    
index = 1;
k = 0.05;
R = 128;
for gg=1:16:size(coin,1)
    for gg1=1:16:size(coin,2)
            temp = coin(gg:gg+15,gg1:gg1+15);
             T  = graythresh(temp)*256+5;%0.5*(min(coin(:)) + max(coin(:)));
             T = mean(temp(:))*(1+k*(std(double(temp(:)))./R-1));
             img(gg:gg+15,gg1:gg1+15) = temp < T;
             index = index +1;
    end
end
disp([num2str(index),' times to get the value']);

%% Manual Thresholding
% if(varStep > varThresh)
%     localBwImg(rowStep,colStep) = im2bw(step,localThresh);
%     uniformMask(rowStep,colStep) = ones(stepSize,stepSize);
%     threshIm(i,j) = localThresh;
%% Display thresholded image
 output = img;
 figure('units','normalized','outerposition',[0 0 1 1]);
 subplot(121),imshow(double(coin),[]);
 subplot(122),imshow(double(output/255),[]);
 title([num2str(gg),' times to get the value'])
end

