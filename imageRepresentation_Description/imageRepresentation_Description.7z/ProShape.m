function ProShape()
%% Define
in_shape = (imread('shape.bmp')); 
shapeBW = (~im2bw(in_shape));      %negative image %might need to do dilation 
[ob_detect,maxObj] = bwlabeln(shapeBW);
%% Display
imshow(in_shape);
%% Detect
for i=1:maxObj
        img = (ob_detect==i);
        [y x] = find(ob_detect==i);
        [a b] = max(y);
        len = max(x) - min(x)+2;
        breadth = max(y) - min(y)+2;
        midPointY = 35+min(y);
        midPointX = 35+min(x);
        if x(min(x)) == x(b)
            if len-breadth>3
                shape = 'rectangle';
            else
                shape = 'square';
            end
        else            
            if len-breadth<3 
                if img(max(y),min(x):max(x))== 1
                     shape = 'Triangle';
                else
                     shape = 'Circle';            
                end
            elseif len-breadth>3
                    shape = 'Oval';            
            end
        end        
        text(midPointX,midPointY+20,shape);
end    
     
end