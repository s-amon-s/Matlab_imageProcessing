function Myblfpad(  )
clc;
close all;
Myblf(imread('square_original.tif'),20,2,'main');
end

